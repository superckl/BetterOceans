/*******************************************************************************
 * Copyright 2011-2014 SirSengir
 * 
 * This work (the API) is licensed under the "MIT" License, see LICENSE.txt for details.
 ******************************************************************************/
@API(apiVersion="1.0", owner="Forestry", provides="ForestryAPI|core")
package forestry.api;
import cpw.mods.fml.common.API;
