Mariculture
===========

This branch is the Mariculture development branch for Minecraft 1.7.2. As of now many things are broken, and are still in the process of being fixed. Trying to run this is not advised, but feel free to help fix any problems.

Mariculture is licensed under MIT

======

##Development
Install Forge-Gradle as standard procedure. You may also need to install the [mariculture_dummy.jar](https://dl.dropboxusercontent.com/u/105284170/mariculture_dummy.jar) in to the mods folder when trying to run.
