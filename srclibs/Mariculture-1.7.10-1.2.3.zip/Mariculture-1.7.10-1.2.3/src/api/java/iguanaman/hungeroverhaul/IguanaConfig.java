package iguanaman.hungeroverhaul;

public class IguanaConfig {
	public static boolean addFoodTooltips;
}
