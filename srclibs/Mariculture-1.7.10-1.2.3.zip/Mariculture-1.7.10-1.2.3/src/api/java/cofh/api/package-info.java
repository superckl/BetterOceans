/**
 * (C) 2014 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API(apiVersion = "1.0", owner = "CoFHLib", provides = "CoFHAPI")
package cofh.api;

import cpw.mods.fml.common.API;

