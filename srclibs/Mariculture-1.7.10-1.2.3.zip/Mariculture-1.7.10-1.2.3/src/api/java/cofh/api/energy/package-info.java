/**
 * (C) 2014 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API(apiVersion = "1.7.10R1.0.0", owner = "CoFHAPI", provides = "CoFHAPI|energy")
package cofh.api.energy;

import cpw.mods.fml.common.API;

