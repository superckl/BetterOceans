package highlands.api;

public class HighlandsBiomes {

}
