package mariculture.api.fishery;

//Implement this on armor that should increase the caught alive chance
public interface ICaughtAliveModifier {
    public double getModifier();
}
