package mariculture.api.fishery;

public class Fishing {
    public static IFishFoodHandler food;
    public static IFishHelper fishHelper;
    public static IMutation mutation;
    public static IFishing fishing;
    public static ISifterHandler sifter;
}
