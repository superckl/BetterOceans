package mcp.mobius.waila.gui.interfaces;

public enum CType {
REL_X,
REL_Y,
RELXY,
ABSXY;
}
