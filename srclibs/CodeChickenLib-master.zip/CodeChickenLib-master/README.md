CodeChickenLib
==============
Formerly known as CodeChickenCore-Public, this is a library of systems to help make various aspects of minecraft modding easier.
It contains libraries for 3D math and transformations, model rendering, packets, config, colours, asm and a few other things.